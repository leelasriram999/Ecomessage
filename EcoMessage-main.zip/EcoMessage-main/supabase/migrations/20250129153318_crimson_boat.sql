/*
  # Chat Application Schema

  1. New Tables
    - `messages`
      - `id` (uuid, primary key)
      - `content` (text) - The message content
      - `sender_id` (uuid) - The authenticated user who sent the message
      - `recipient_id` (uuid) - The user who receives the message
      - `is_anonymous` (boolean) - Whether the message is sent anonymously
      - `created_at` (timestamp) - When the message was sent
  
  2. Security
    - Enable RLS on `messages` table
    - Add policies for:
      - Users can insert messages
      - Users can read messages where they are either sender or recipient
*/

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  sender_id uuid REFERENCES auth.users(id),
  recipient_id uuid REFERENCES auth.users(id),
  is_anonymous boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Allow users to send messages
CREATE POLICY "Users can send messages"
  ON messages
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = sender_id);

-- Allow users to read messages where they are sender or recipient
CREATE POLICY "Users can read their messages"
  ON messages
  FOR SELECT
  TO authenticated
  USING (auth.uid() = sender_id OR auth.uid() = recipient_id);